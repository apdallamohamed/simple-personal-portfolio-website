import React from 'react'
import './Skills.css'
function Skills() {
  return (
  
    <div>
    <div class="skill">

    <h1 className='h1'>My Skills</h1>
    
    </div>
    <div className="btn">
      <button>html</button>
      <button>css</button>
      <button>javascript</button>
      <button>React</button>
      
      


    </div>
    <div className="btn1">
      <button>java</button>
      <button>mongodb</button>
      <button>flutter</button>
      <button>Django</button>
      


    </div>

   
      
    </div>
    
  )
}

export default Skills


