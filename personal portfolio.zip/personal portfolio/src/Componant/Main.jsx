import React from 'react'
import './Main.css'
function Main() {
  return (
    <div>
      <div class="container">
       <h1>Hi,I'am <span className='name'>Apdalla</span><br/><span>I'm fullstack developer</span><br/
       ><h7>welcom to my portfolio</h7></h1>
       <img src="/images/aq.jfif" alt="sawir soo gasho" />
       <a className='button' href='###' >Show</a>
       </div>
       
       
    </div>
  )
  }
export default Main
